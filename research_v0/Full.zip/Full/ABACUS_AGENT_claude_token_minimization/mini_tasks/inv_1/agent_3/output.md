# Agent 3 Output — Session-/Memory-Management & Hooks-/Guards-Repos

## Aufgabe
Recherche von 16 GitHub-Repos für Claude-Code-Tokenminimierung (Session-/Memory-Management sowie Hooks-/Guards). Für jedes Repo: Was es tut, wie es Tokens spart, Integrationstyp, Relevanzscore 1-5.

## Ergebnis
Alle 16 Repos erfolgreich per scrape_url_content auf GitHub-README geprüft. Alle existieren und sind öffentlich. Vollständige strukturierte Ausgabe in **/home/ubuntu/research_worker4.md** geschrieben.

## Kernbefunde (Top-Relevanz, Score 5)
- **NodeNestor/claude-rolling-context** — Rolling Context Compression: kappt Context-Prefix, macht Input-Kosten linear statt quadratisch. Proxy + Plugin.
- **JuliusBrussee/caveman** — Output-Kompression (Skill, ~65%) + Input-Payload-Engine (Proxy) + Pixel-Mode. 97.8k Stars.
- **thedotmack/claude-mem** — Progressive-Disclosure Memory-Retrieval (3-Layer: search→timeline→get_observations). 90.6k Stars.
- **deusdata/codebase-memory-mcp** — Graph-basierte Code-Exploration, 120× weniger Tokens (3.400 vs 412.000).
- **cnighswonger/claude-code-cache-fix** — Prompt-Cache-Optimierung, erhöht Cache-Read-Ratio, spart ~1.800 Tokens/Request via GIT-Instructions-Disable.

## Weitere Scores
- Score 4: mempalace, zilliztech/memsearch, severity1/claude-code-auto-memory, DietrichGebert/ponytail, severity1/claude-code-prompt-improver, ramakay/claude-self-reflect
- Score 3: Vvkmnn/claude-historian-mcp
- Score 2: zippoxer/recall, karanb192/claude-code-hooks
- Score 1: disler/claude-code-hooks-multi-agent-observability, yifanzz/claude-code-boost

## Dateien
- **/home/ubuntu/research_worker4.md** — primäre strukturierte Ausgabe (16 Repos, Ranking-Tabelle, Details)
- **/home/ubuntu/mini_tasks/inv_1/agent_3/output.md** — diese Zusammenfassung

## Hinweise
- COVERAGE BOUND (16 Repos) erreicht — Recherche abgeschlossen.
- Bei einigen Repos war die Star-Zahl im Scrape nicht sichtbar (rolling-context, mempalace, codebase-memory-mcp, auto-memory, ponytail, cache-fix, claude-code-hooks, self-reflect, boost).
- Keine Repos privat oder nicht existent.
