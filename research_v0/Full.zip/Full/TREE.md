[6.7M]  .
├── [1.1M]  ABACUS_AGENT_claude_token_minimization
│   ├── [103K]  document.html
│   ├── [339K]  document.pdf
│   ├── [245K]  mini_tasks
│   │   ├── [9.5K]  discovery_placeholder.docx
│   │   ├── [  29]  discovery_placeholder.md
│   │   ├── [4.7K]  discovery_placeholder.pdf
│   │   ├── [ 64K]  inv_0
│   │   │   ├── [ 61K]  agent_0
│   │   │   │   ├── [ 721]  discovered_raw.txt
│   │   │   │   ├── [3.0K]  exclusion_list.txt
│   │   │   │   ├── [ 13K]  output.docx
│   │   │   │   ├── [6.0K]  output.md
│   │   │   │   └── [ 38K]  output.pdf
│   │   │   └── [3.1K]  agent_2
│   │   │       └── [3.0K]  exclusion_list.txt
│   │   └── [167K]  inv_1
│   │       ├── [ 32K]  agent_0
│   │       │   ├── [ 11K]  output.docx
│   │       │   ├── [2.0K]  output.md
│   │       │   └── [ 19K]  output.pdf
│   │       ├── [ 33K]  agent_1
│   │       │   ├── [ 11K]  output.docx
│   │       │   ├── [2.4K]  output.md
│   │       │   └── [ 19K]  output.pdf
│   │       ├── [ 36K]  agent_2
│   │       │   ├── [ 11K]  output.docx
│   │       │   ├── [2.8K]  output.md
│   │       │   └── [ 21K]  output.pdf
│   │       ├── [ 30K]  agent_3
│   │       │   ├── [ 11K]  output.docx
│   │       │   ├── [2.1K]  output.md
│   │       │   └── [ 17K]  output.pdf
│   │       └── [ 35K]  agent_4
│   │           ├── [ 11K]  output.docx
│   │           ├── [2.0K]  output.md
│   │           └── [ 22K]  output.pdf
│   ├── [ 18K]  research_worker1.docx
│   ├── [ 17K]  research_worker1.md
│   ├── [ 46K]  research_worker1.pdf
│   ├── [ 17K]  research_worker2.docx
│   ├── [ 14K]  research_worker2.md
│   ├── [ 40K]  research_worker2.pdf
│   ├── [ 17K]  research_worker3.docx
│   ├── [ 15K]  research_worker3.md
│   ├── [ 41K]  research_worker3.pdf
│   ├── [ 19K]  research_worker4.docx
│   ├── [ 18K]  research_worker4.md
│   ├── [ 49K]  research_worker4.pdf
│   ├── [ 18K]  research_worker5.docx
│   ├── [ 18K]  research_worker5.md
│   ├── [ 47K]  research_worker5.pdf
│   └── [ 12K]  Uploads
│       └── [ 12K]  user_message_2026-08-13_00-30-41.txt
├── [506K]  GPT55SOL_PRO_claude-token-stack-research-v3
│   ├── [2.0K]  bash-dump-guard.config.json
│   ├── [ 46K]  bash-dump-guard.mjs
│   ├── [2.3K]  CHANGELOG.md
│   ├── [2.1K]  claude-code-hooks.example.json
│   ├── [ 28K]  claude-code-token-stack-research-2026-08-10.md
│   ├── [ 13K]  claude-hook-capability-canary.mjs
│   ├── [2.3K]  context-surface-owners.template.yaml
│   ├── [3.5K]  install-bash-dump-guard.ps1
│   ├── [3.9K]  install-bash-dump-guard.sh
│   ├── [6.1K]  install-token-stack-hooks.ps1
│   ├── [4.5K]  install-token-stack-hooks.sh
│   ├── [7.1K]  lib
│   │   └── [7.0K]  token-stack-shared.mjs
│   ├── [1005]  native-token-limits.example.jsonc
│   ├── [5.3K]  package-manifest.json
│   ├── [ 589]  prefix-budget.config.json
│   ├── [ 20K]  prefix-budget.mjs
│   ├── [1.0K]  read-context-guard.config.json
│   ├── [8.4K]  read-context-guard.mjs
│   ├── [4.1K]  read-slice-guard.mjs
│   ├── [5.5K]  README.md
│   ├── [141K]  repo-catalog.json
│   ├── [ 80K]  repo-catalog.md
│   ├── [6.2K]  repo-shortlist-matrix.md
│   ├── [4.5K]  reread-guard.mjs
│   ├── [ 605]  session-economy.config.json
│   ├── [ 19K]  session-economy.mjs
│   ├── [3.1K]  SHA256SUMS.txt
│   ├── [ 28K]  sources
│   │   └── [ 28K]  token-stack-konzept-2026-08.md
│   ├── [8.2K]  target-stack-profiles.yaml
│   ├── [1.4K]  TASK-STATE.template.md
│   ├── [6.6K]  tests
│   │   └── [6.5K]  hook-contract-smoke.mjs
│   ├── [5.9K]  token-efficiency.rules.md
│   ├── [9.2K]  token-stack-benchmark-plan.md
│   ├── [ 19K]  token-stack-konzept-2026-08.optimized.md
│   └── [4.7K]  verify-package.sh
├── [4.0M]  KIMI_AGENT_claude-code-token-stack-konzept
│   ├── [ 29K]  cc-token-stack_ref.md
│   ├── [ 15K]  cc-token-stack_sec01.md
│   ├── [ 16K]  cc-token-stack_sec02.md
│   ├── [ 17K]  cc-token-stack_sec03.md
│   ├── [ 24K]  cc-token-stack_sec04.md
│   ├── [ 19K]  cc-token-stack_sec05.md
│   ├── [ 22K]  cc-token-stack_sec06.md
│   ├── [ 15K]  cc-token-stack_sec07.md
│   ├── [ 23K]  cc-token-stack_sec08.md
│   ├── [ 38K]  cc-token-stack_sec09.md
│   ├── [168K]  cc-token-stack.agent.final.base.docx
│   ├── [218K]  cc-token-stack.agent.final.converted.md
│   ├── [1.0M]  cc-token-stack.agent.final.footnote.docx
│   ├── [219K]  cc-token-stack.agent.final.md
│   ├── [ 14K]  cc-token-stack.agent.outline.md
│   ├── [ 35K]  cc-token-stack.citation.jsonl
│   ├── [ 52K]  chart_advertised_vs_real.png
│   ├── [1.0M]  Claude-Code-Token-Stack-Konzept.docx
│   ├── [219K]  Claude-Code-Token-Stack-Konzept.md
│   ├── [2.6K]  plan.md
│   └── [824K]  research
│       ├── [4.8K]  cc-token_cross_verification_nachtrag.md
│       ├── [8.3K]  cc-token_cross_verification.md
│       ├── [ 44K]  cc-token_dim01.md
│       ├── [ 52K]  cc-token_dim02.md
│       ├── [ 39K]  cc-token_dim03.md
│       ├── [ 33K]  cc-token_dim04.md
│       ├── [ 38K]  cc-token_dim05.md
│       ├── [ 31K]  cc-token_dim06.md
│       ├── [ 32K]  cc-token_dim07.md
│       ├── [ 40K]  cc-token_dim08.md
│       ├── [8.1K]  cc-token_insight.md
│       ├── [ 30K]  cc-token_repo_matrix.md
│       ├── [ 53K]  cc-token_wide01.md
│       ├── [ 36K]  cc-token_wide02.md
│       ├── [ 34K]  cc-token_wide03.md
│       ├── [ 24K]  cc-token_wide04.md
│       ├── [ 27K]  cc-token_wide05.md
│       ├── [ 33K]  cc-token_wide06.md
│       └── [257K]  readmes
│           ├── [ 19K]  c0ntextkeeper.md
│           ├── [1.6K]  context-gateway.md
│           ├── [ 13K]  contextzip.md
│           ├── [ 12K]  densely.md
│           ├── [ 15K]  furlctx.md
│           ├── [ 35K]  headroom.md
│           ├── [ 37K]  llmtrim.md
│           ├── [9.3K]  magic-compact.md
│           ├── [ 22K]  omniglyph.md
│           ├── [ 21K]  pxpipe.md
│           ├── [ 22K]  rolling-context.md
│           ├── [6.3K]  squeezr-prompt-cache.md
│           ├── [ 15K]  squeezr.md
│           ├── [ 27K]  tokdiet.md
│           └── [1.4K]  tokensnap.md
├── [924K]  MANUS_AGENT_kontextbewussten-ki-entwicklungsstack
│   ├── [3.2K]  analyse_repos.py
│   ├── [7.1K]  Architekturentscheidungen für den kontextbewussten KI-Entwicklungsstack.md
│   ├── [5.7K]  article-structure.md
│   ├── [ 855]  berechne_scores.py
│   ├── [2.4K]  erzeuge_kandidaten_heatmap.py
│   ├── [2.5K]  erzeuge_vergleichsdiagramm.py
│   ├── [ 12K]  Gewichtete Vergleichsmatrix der priorisierten Repositories.md
│   ├── [122K]  gewichtete_repo_bewertung.png
│   ├── [ 15K]  Implementierungsfahrplan für die Pilotphase.md
│   ├── [131K]  kandidaten_heatmap.png
│   ├── [ 30K]  Kontextengineering für KI-Coding-Agents: erweiterte Repository- und Architekturentscheidung.md
│   ├── [ 26K]  Konzept für einen kontextbewussten KI-Entwicklungsstack.md
│   ├── [3.7K]  Normalisiertes Repository-Inventar.md
│   ├── [ 12K]  pasted_content.txt
│   ├── [ 29K]  recherche_notizen.md
│   ├── [ 16K]  SKILL.md
│   ├── [ 861]  vergleichsscores_berechnet.csv
│   ├── [ 737]  vergleichsscores.csv
│   ├── [1.5K]  zielarchitektur.mmd
│   └── [501K]  zielarchitektur.png
├── [276K]  OPUS5_MAX_claude-token-stack-v3-2
│   ├── [2.7K]  CHANGELOG.md
│   ├── [3.5K]  context-surface-owners.yaml
│   ├── [ 12K]  prefix-budget.mjs
│   ├── [2.8K]  README.md
│   ├── [159K]  repo-catalog-v3.json
│   ├── [ 62K]  repo-catalog-v3.md
│   ├── [ 692]  SHA256SUMS.txt
│   ├── [6.0K]  token-efficiency.rules.v3.md
│   └── [ 27K]  token-stack-konzept-v3.md
└── [   0]  tree.txt

 6.7M used in 22 directories, 160 files
